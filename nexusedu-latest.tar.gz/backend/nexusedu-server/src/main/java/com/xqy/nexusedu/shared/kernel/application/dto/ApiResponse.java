package com.xqy.nexusedu.shared.kernel.application.dto;

import java.io.Serializable;

import com.xqy.nexusedu.shared.kernel.domain.constant.CommonCode;

/**
 * 通用 API 响应结构
 */
public class ApiResponse<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    private int code;
    private String message;
    private T data;

    public ApiResponse() {
    }

    public ApiResponse(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(CommonCode.SUCCESS.getCode(), CommonCode.SUCCESS.getMessage(), data);
    }

    public static <T> ApiResponse<T> fail(CommonCode errorCode) {
        return new ApiResponse<>(errorCode.getCode(), errorCode.getMessage(), null);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    /**
     * Alias used by the nexusedu-ui response contract.
     */
    public String getMsg() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Alias used when a client sends the nexusedu-ui response field name.
     */
    public void setMsg(String msg) {
        this.message = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
