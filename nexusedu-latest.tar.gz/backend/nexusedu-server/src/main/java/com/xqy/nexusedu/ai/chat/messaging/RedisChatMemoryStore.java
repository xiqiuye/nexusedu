package com.xqy.nexusedu.ai.chat.messaging;

import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.ChatMessageDeserializer;
import dev.langchain4j.data.message.ChatMessageSerializer;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import java.util.List;
import java.util.Objects;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/** Stores LangChain4j chat memory as JSON values in Redis. */
@Component
public class RedisChatMemoryStore implements ChatMemoryStore {

    private static final String KEY_PREFIX = "chat-memory:";

    private final StringRedisTemplate redisTemplate;



    public RedisChatMemoryStore(StringRedisTemplate redisTemplate) {
       this.redisTemplate = redisTemplate;
    }



    @Override
    public List<ChatMessage> getMessages(Object memoryId) {
        String messagesJson = redisTemplate.opsForValue().get(key(memoryId));
        if (messagesJson == null) {
            return List.of();
        }
        return ChatMessageDeserializer.messagesFromJson(messagesJson);
    }

    @Override
    public void updateMessages(Object memoryId, List<ChatMessage> messages) {
        Objects.requireNonNull(messages, "messages must not be null");
        String messagesJson = ChatMessageSerializer.messagesToJson(messages);
        redisTemplate.opsForValue().set(key(memoryId), messagesJson);
    }

    public void initializeIfAbsent(Object memoryId, List<ChatMessage> messages) {
        if (!messages.isEmpty()) redisTemplate.opsForValue().setIfAbsent(key(memoryId), ChatMessageSerializer.messagesToJson(messages));
    }

    @Override
    public void deleteMessages(Object memoryId) {
        redisTemplate.delete(key(memoryId));
    }

    private String key(Object memoryId) {
        return KEY_PREFIX + Objects.requireNonNull(memoryId, "memoryId must not be null");
    }
}
