package com.xqy.nexusedu.ai.tools.service;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.xqy.nexusedu.education.student.profile.service.StudentService;
import com.xqy.nexusedu.education.student.profile.vo.StudentData;
import com.xqy.nexusedu.ai.task.model.AiTask;
import com.xqy.nexusedu.ai.task.model.AiExecutionContext;
import com.xqy.nexusedu.ai.task.model.AiTaskResult;
import com.xqy.nexusedu.ai.task.model.QueryCriteria;
import com.xqy.nexusedu.ai.task.model.QueryFilterNode;

/** AI-facing adapter for the student domain. */
@Service
public class StudentBusinessService {

    @Autowired
    private StudentService studentService;

    public AiTaskResult queryStudent(AiTask task) {
        AiExecutionContext context=task==null?null:task.getExecutionContext();
        AiTaskResult result = queryStudent(task == null ? null : task.getQuery(),context==null?null:context.getTenantId(),context==null?null:context.getUserId());
        if (task != null) {
            result.setDomain(task.getDomain());
            result.setToolName(task.getToolName());
            result.setQuestion(task.getSubQuestion());
        }
        return result;
    }

    /** Queries the student provider using the planner's normalized criteria. */
    public AiTaskResult queryStudent(QueryCriteria criteria) {
        return queryStudent(criteria,null,null);
    }

    private AiTaskResult queryStudent(QueryCriteria criteria,String tenantId,Long userId) {
        StudentQueryValues values = extractValues(criteria == null ? null : criteria.getFilter());
        int limit = criteria == null ? 100 : criteria.getLimit();
        List<StudentData> students = studentService.queryStudents(values.name(), values.gender(), values.studentNo(), limit,tenantId,userId);
        students.forEach(student->{student.setBirthday(null);student.setEmail(null);student.setPhone(null);student.setAge(null);});
        Map<String, Object> summary = new HashMap<>();
        summary.put("count", students.size());
        summary.put("domain", "student");
        summary.put("toolName", "query_student");
        AiTaskResult result = new AiTaskResult();
        result.setDomain("student");
        result.setToolName("query_student");
        result.setSuccess(true);
        result.setQuery(criteria);
        result.setItems(students);
        result.setSummary(summary);
        return result;
    }

    private StudentQueryValues extractValues(QueryFilterNode node) {
        StudentQueryValues values = new StudentQueryValues();
        collectLeaves(node, values);
        return values;
    }

    private void collectLeaves(QueryFilterNode node, StudentQueryValues values) {
        if (node == null) {
            return;
        }
        if (node.getField() != null && node.getOperator() != null) {
            String field = node.getField();
            String operator = node.getOperator().toUpperCase(Locale.ROOT);
            Object rawValue = node.getValue();
            String value = rawValue == null ? null : String.valueOf(rawValue);
            if ("name".equals(field) && ("LIKE".equals(operator) || "EQ".equals(operator))) {
                values.name(value);
            } else if ("gender".equals(field) && "EQ".equals(operator)) {
                values.gender(value);
            } else if ("studentNo".equals(field) && "EQ".equals(operator)) {
                values.studentNo(value);
            } else if ("name".equals(field) || "gender".equals(field) || "studentNo".equals(field)) {
                throw new IllegalArgumentException("Unsupported student query operator: " + operator);
            } else {
                throw new IllegalArgumentException("Unsupported student query field: " + field);
            }
        }
        if (node.getAnd() != null) {
            node.getAnd().forEach(child -> collectLeaves(child, values));
        }
        if (node.getOr() != null && !node.getOr().isEmpty()) {
            throw new IllegalArgumentException("Student query does not support OR filters yet");
        }
        if (node.getNot() != null) {
            throw new IllegalArgumentException("Student query does not support NOT filters yet");
        }
    }

    private static final class StudentQueryValues {
        private String name;
        private String gender;
        private String studentNo;

        String name() { return name; }
        String gender() { return gender; }
        String studentNo() { return studentNo; }
        void name(String value) { this.name = value; }
        void gender(String value) { this.gender = value; }
        void studentNo(String value) { this.studentNo = value; }
    }
}
